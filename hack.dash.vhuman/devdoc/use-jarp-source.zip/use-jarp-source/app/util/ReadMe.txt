ThreadUtilities
  David R. Nadeau
  NadeauSoftware.com

  These files are distributed under version 2 of the
  Lesser General Public License.  Please note the
  copyright statement in the source code, and the
  included GPL 2.0 license.

  Published credit for this code is appreciated, but
  not required.

  Please see the accompanying article:

  http://nadeausoftware.com/articles/2008/04/java_tip_how_list_and_find_threads_and_thread_groups
